package com.scwang.smartrefresh.layout.api;

/**
 * 刷新头部
 * Created by scwang on 2017/5/26.
 */
public interface RefreshHeader extends RefreshInternal {

}
