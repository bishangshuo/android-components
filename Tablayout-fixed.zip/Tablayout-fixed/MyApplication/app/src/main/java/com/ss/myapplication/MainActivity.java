package com.ss.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;

import com.ss.myapplication.tablayout.XTabLayout;
import com.ss.myapplication.utils.AppBarStateChangeListener;


public class MainActivity extends AppCompatActivity {

    private AppBarLayout app_bar_topic;
    private ImageView iv_back_topic;
    private Toolbar toolbar_topic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitingfriends);
        ViewPager mViewPager= (ViewPager) findViewById(R.id.viewpager);
        XTabLayout mTabLayout= (XTabLayout) findViewById(R.id.tablayout);

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(viewPagerAdapter);
        mTabLayout.setxTabDisplayNum(2);
        viewPagerAdapter=new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addItem(new DemoFragment(),"收益总榜");
        viewPagerAdapter.addItem(new DemoFragment(),"我邀请的会员");
        mViewPager.setAdapter(viewPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        app_bar_topic = (AppBarLayout) findViewById(R.id.app_bar_topic);
        iv_back_topic = (ImageView) findViewById(R.id.iv_back_topic);
        toolbar_topic = (Toolbar) findViewById(R.id.toolbar_topic);

        initappBar();

    }


    private void initappBar() {
        app_bar_topic.addOnOffsetChangedListener(new AppBarStateChangeListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, State state) {
                if( state == State.EXPANDED ) {
                    iv_back_topic.setImageResource(R.mipmap.back_white);
                    toolbar_topic.setBackgroundColor(Color.argb((int) 0, 0, 0, 0));
                    //展开状态
                }else if(state == State.COLLAPSED){
                    iv_back_topic.setImageResource(R.mipmap.search_back);
                    toolbar_topic.setBackgroundColor(Color.argb((int) 255, 255, 255, 255));
                    //折叠状态
                }else {
                    iv_back_topic.setImageResource(R.mipmap.back_white);
                    toolbar_topic.setBackgroundColor(Color.argb((int) 0, 0, 0, 0));
                    //中间状态
                }
            }
        });
    }
}
