# TabLayoutRV
TabLayout和RecyclerView结合，点击TabLayout会切换到对应的RecyclerView位置，滚动RecyclerView时TabLayout会跟着切换到对应位置。

<a href="https://github.com/hnsycsxhzcsh/TabLayoutRV/blob/master/myres/tablayoutrv.apk">Download Apk</a>

效果图

<img src="https://github.com/hnsycsxhzcsh/TabLayoutRV/blob/master/myres/tablayoutrv.gif" width="300" height="612">

具体实现原理可以浏览我的博客：https://mp.csdn.net/postedit/85120375

如果有帮助到大家希望点下右上角Star，谢谢！

