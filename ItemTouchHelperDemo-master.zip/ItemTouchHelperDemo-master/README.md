# ItemTouchHelperDemo
使用ItemTouchHelper实现今日头条 网易新闻 的频道排序、频道移动

# 效果演示
![部分效果演示.gif](http://upload-images.jianshu.io/upload_images/937851-2df50ff9833dd386.gif?imageMogr2/auto-orient/strip)

# 源码分析
查看[我的这篇简书](http://www.jianshu.com/p/d30fd8da4eac)
