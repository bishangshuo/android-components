# Version 2.0.0

* Migrate to androidx 1.0.0
* Remove util-v13 library

# Version 1.7.0

* Update support library version to 28.0.0
* Change target sdk version to 28
* Change min sdk version to 14
* Deprecated util-v13 library

# Version 1.6.1

* Fixed issue with center last item in always in center tablayout #160

# Version 1.6.0

* Add `stl_indicatorWidth` to custom indicator's width #106

# Version 1.5.1

* Fixed indicator position of auto_center #100

# Version 1.5.0

* Add `stl_drawDecorationAfterTab` attribute for change the drawing order #58
* Add `stl_titleOffset` attribute for adjust the slide position #89
* Fixed a condition code of onSizeChanged for always in center

# Version 1.4.2

* Change the call order of OnTabClickListener when press the tab #74

# Version 1.4.1

* Update android support library version to 22.2.1

# Version 1.4.0

* Add TabClickListener interface #68

# Version 1.3.0

* RTL support #48
* Add `stl_clickable` attribute.

# Version 1.2.3

* Modify to ensure the first scroll #54

# Version 1.2.2

* Fix bug when indicatorAlwaysInCenter is true and tabHost has only two tabs #50

# Version 1.2.1

* Add custom ScrollListener interface #46

# Version 1.2.0

* Support the margin of each tab.
* Add `stl_indicatorWithoutPadding` and `stl_indicatorGravity` attributes.
* Add `stl_overlineColor` and `stl_overlineThickness` attributes.

# Version 1.1.3

* Allow to set the background on default tab #13

# Version 1.1.2

* Added setter for tab text colors #10
* Allow to set a String title dynamically on PagerItems. #7

# Version 1.1.1

* Enable the format of ‘reference’ for defaultTextColor to support ColorStateList #3

# Version 1.1.0

* Supported Icon Tab. #1


# Version 1.0.0

* Initial release.
