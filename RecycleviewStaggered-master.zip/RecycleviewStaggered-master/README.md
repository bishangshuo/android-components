
# RecycleviewStaggered</br>
recycleview进阶用法，实现复杂页面，包含瀑布流。最主要的类就是HomepagerRecycleAdapter，适配器

效果图：

![效果图](https://github.com/385841539/RecycleviewStaggered/blob/master/app/src/main/res/drawable/qianqiou.jpg)

实现原理请看博客：http://blog.csdn.net/iamdingruihaha/article/details/54772834

有问题欢迎多多反馈，相信我们会做的更好）
