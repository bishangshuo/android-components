package com.example.myrecyclviewdemo.Constants;


public class Contants {


    public static class API {


        public static final String HOST_SLIDLAYOUT = "http://112.124.22.238:8" +
                "081/course_api/banner/query?type=1";
        public static final String BASE_URL = "http://112.124.22.238:8081/course_api/";

        public static final String CAMPAIGN_HOME = BASE_URL + "campaign/recommend";


    }
}
